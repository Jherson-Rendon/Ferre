export interface ProductoCart {
    ref: number;
    nombre: string;
    precio: number;
    cantidad: number;
}
